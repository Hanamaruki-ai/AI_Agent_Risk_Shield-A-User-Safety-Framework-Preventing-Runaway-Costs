﻿# 🛡️ AI Agent Safety Advisory Repository  
### **AIエージェント安全アドバイザリ（正式公開版）**

---

# 🔔 【警鐘｜Public Safety Warning】  
このフォルダは、AIエージェントモードの急速な普及に伴い、  
**一般ユーザー・企業・教育者・研究者が重大な損害を受ける前に警鐘を鳴らすため** に  
正式に作成された **公共安全アドバイザリ（Public Safety Advisory）** です。

この資料は特定の企業・団体を非難するものではなく、  
**AI技術の誤用・暴走・高額請求による被害を未然に防ぐ目的** で公開されています。

---

# 🟦 【背景と経緯｜Background & Motivation】

本リポジトリで公開している安全資料の一部は、  
かつて別のリポジトリに “ひっそり” と掲載していました。

しかし、AIエージェントの普及速度が想定を超え、  
誤設定・誤解・暴走挙動によって  
**一般ユーザーや企業が深刻な財務的・技術的損害を受ける危険性** が高まっています。

特に、被害を受ける可能性のある人々の中には  
**自分の友人・知人・未来のユーザーも含まれるかもしれない**  
という強い危機感がありました。

そのため、透明性と公共性を確保する目的で、  
**専用フォルダを新規作成し、資料を正式に移管して公開しています。**

なお、誤解防止のため、以前掲載していたリポジトリからは  
**すべての関連資料を削除済みであり、ここが正式な公開場所です。**

---

# 📁 **フォルダ内容（Documents）**

このフォルダには、AIエージェント安全性に関する  
最重要ドキュメントが格納されています。

docs/
│
├ api_electricity_pricing.md
│ └─ APIを「電力消費（kWh）」へ変換し、公平かつ透明な課金モデルを提示する文書。
│
└ agent_risk_insight_log.md
└─ AIエージェントの暴走挙動・制御不能性を示すログ（公共安全目的の参考資料）。


---

# ⚠️ **注意｜Disclaimer**

- 本資料は企業・個人を攻撃・批判する意図はありません。  
- 公共の安全を守る目的のみで作成されています。  
- 商用テンプレート・詐欺勧誘への転用は禁止です。  
- 公益目的であれば、引用・再利用・翻訳は自由です。

---

# 🌐 **English Section**

## 🛡️ AI Agent Safety Advisory Repository  
This folder is an official **public safety advisory**,  
created to protect global users and organizations  
from the rapid rise of autonomous AI agents and the serious risks they can produce—  
including runaway API usage, uncontrolled task loops, and catastrophic billing.

This repository does **not** criticize any company or product.  
Its sole purpose is to **warn and protect users before harm occurs**.

---

## 🔎 Background & Motivation  
Some of the documents contained here were originally uploaded quietly in another repository.  
However, as autonomous agents began spreading far faster than anticipated,  
the risk of **users, organizations, and even personal acquaintances suffering real damage**  
became impossible to ignore.

To ensure transparency and clarity,  
all materials have been **formally migrated into this dedicated folder**,  
and all previous copies have been **fully removed from older repositories**.

This folder now serves as the **official and authoritative public location**  
for all AI agent safety materials.

---

## 📁 Folder Contents


docs/
│
├ api_electricity_pricing.md
│ └─ Proposal for converting API usage into physical electricity units (kWh)
│ to ensure fair and predictable billing for AI agents.
│
└ agent_risk_insight_log.md
└─ Evidence logs illustrating uncontrolled agent behavior
and potential safety risks in real-world environments.


---

## ⚠️ Disclaimer  
- This advisory is **not** intended to attack or defame any entity.  
- Documents may be freely reused for **public safety, education, or research**.  
- Commercial exploitation or use in scams is strictly prohibited.

---

# 📌 **This folder is the official home of all AI Agent Safety Advisory documents.**  
